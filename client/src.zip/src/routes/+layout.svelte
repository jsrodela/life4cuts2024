<div class="grid place-items-center w-full h-full">
  <slot />
</div>

<script>
  import '$lib/styles/global.css';
</script>
