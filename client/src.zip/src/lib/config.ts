export default {
  frames: ["/frame1.png","/frame2.png"]
}
